<!-- Donor Profile Modal-->
<div id="donorProfile">
	<!-- Popup Div Starts Here -->
	<div id="donorPanelForm">
		<div class="loaderadd"></div>
		<div class="close"  onclick="div_donor_hide()"><?php esc_html_e( 'X', 'idonate' ); ?></div>
		<div class="ta-row">
			<div class="ta-col-xl-2-5 mx-auto">
				<div class="contentapp"></div>
			</div>
		</div>
	</div>
	<!-- Popup Div Ends Here -->
</div>