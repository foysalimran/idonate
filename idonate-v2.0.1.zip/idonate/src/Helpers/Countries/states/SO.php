<?php

global $states;

$states['SO'] = [
    'AWDAL'            => __( 'Awdal', 'idonate' ),
    'BAKOOL'           => __( 'Bakool', 'idonate' ),
    'BANAADIR'         => __( 'Banaadir', 'idonate' ),
    'BARI'             => __( 'Bari', 'idonate' ),
    'BAY'              => __( 'Bay', 'idonate' ),
    'GALGUDUUD'        => __( 'Galguduud', 'idonate' ),
    'GEDO'             => __( 'Gedo', 'idonate' ),
    'HIIRAAN'          => __( 'Hiiraan', 'idonate' ),
    'JUBBADADHEXE'     => __( 'Jubbada Dhexe', 'idonate' ),
    'JUBBADAHOOSE'     => __( 'Jubbada Hoose', 'idonate' ),
    'MUDUG'            => __( 'Mudug', 'idonate' ),
    'NUGAAL'           => __( 'Nugaal', 'idonate' ),
    'SANAAG'           => __( 'Sanaag', 'idonate' ),
    'SHABEELLAHADHEXE' => __( 'Shabeellaha Dhexe', 'idonate' ),
    'SHABEELLAHAHOOSE' => __( 'Shabeellaha Hoose', 'idonate' ),
    'SOOL'             => __( 'Sool', 'idonate' ),
    'TOGDHEER'         => __( 'Togdheer', 'idonate' ),
    'WOQOOYIGALBEED'   => __( 'Woqooyi Galbeed', 'idonate' ),
];
