<?php

global $states;

$states['AO'] = [
    'BENGO'         => __( 'Bengo', 'idonate' ),
    'BENGUELA'      => __( 'Benguela', 'idonate' ),
    'BIE'           => __( 'Bie', 'idonate' ),
    'CABINDA'       => __( 'Cabinda', 'idonate' ),
    'CUANDOCUBANGO' => __( 'Cuando Cubango', 'idonate' ),
    'CUANZANORTE'   => __( 'Cuanza Norte', 'idonate' ),
    'CUANZASUL'     => __( 'Cuanza Sul', 'idonate' ),
    'CUNENE'        => __( 'Cunene', 'idonate' ),
    'HUAMBO'        => __( 'Huambo', 'idonate' ),
    'HUILA'         => __( 'Huila', 'idonate' ),
    'LUANDA'        => __( 'Luanda', 'idonate' ),
    'LUNDANORTE'    => __( 'Lunda Norte', 'idonate' ),
    'LUNDASUL'      => __( 'Lunda Sul', 'idonate' ),
    'MALANJE'       => __( 'Malanje', 'idonate' ),
    'MOXICO'        => __( 'Moxico', 'idonate' ),
    'NAMIBE'        => __( 'Namibe', 'idonate' ),
    'UIGE'          => __( 'Uige', 'idonate' ),
    'ZAIRE'         => __( 'Zaire', 'idonate' ),
];
