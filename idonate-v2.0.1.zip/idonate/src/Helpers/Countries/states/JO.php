<?php

global $states;

$states['JO'] = [
    'AJLUN'     => __( 'Ajlun', 'idonate' ),
    "AL'AQABAH" => __( "Al 'Aqabah", 'idonate' ),
    "ALBALQA'"  => __( "Al Balqa'", 'idonate' ),
    'ALKARAK'   => __( 'Al Karak', 'idonate' ),
    'ALMAFRAQ'  => __( 'Al Mafraq', 'idonate' ),
    "'AMMAN"    => __( "'Amman", 'idonate' ),
    'ATTAFILAH' => __( 'At Tafilah', 'idonate' ),
    "AZZARQA'"  => __( "Az Zarqa'", 'idonate' ),
    'IRBID'     => __( 'Irbid', 'idonate' ),
    'JARASH'    => __( 'Jarash', 'idonate' ),
    "MA'AN"     => __( "Ma'an", 'idonate' ),
    'MADABA'    => __( 'Madaba', 'idonate' ),
];
