<?php

global $states;

$states['EC'] = [
    'AZUAY'            => __( 'Azuay', 'idonate' ),
    'BOLIVAR'          => __( 'Bolivar', 'idonate' ),
    'CANAR'            => __( 'Canar', 'idonate' ),
    'CARCHI'           => __( 'Carchi', 'idonate' ),
    'CHIMBORAZO'       => __( 'Chimborazo', 'idonate' ),
    'COTOPAXI'         => __( 'Cotopaxi', 'idonate' ),
    'ELORO'            => __( 'El Oro', 'idonate' ),
    'ESMERALDAS'       => __( 'Esmeraldas', 'idonate' ),
    'GALAPAGOS'        => __( 'Galapagos', 'idonate' ),
    'GUAYAS'           => __( 'Guayas', 'idonate' ),
    'IMBABURA'         => __( 'Imbabura', 'idonate' ),
    'LOJA'             => __( 'Loja', 'idonate' ),
    'LOSRIOS'          => __( 'Los Rios', 'idonate' ),
    'MANABI'           => __( 'Manabi', 'idonate' ),
    'MORONA-SANTIAGO'  => __( 'Morona-Santiago', 'idonate' ),
    'NAPO'             => __( 'Napo', 'idonate' ),
    'ORELLANA'         => __( 'Orellana', 'idonate' ),
    'PASTAZA'          => __( 'Pastaza', 'idonate' ),
    'PICHINCHA'        => __( 'Pichincha', 'idonate' ),
    'SUCUMBIOS'        => __( 'Sucumbios', 'idonate' ),
    'TUNGURAHUA'       => __( 'Tungurahua', 'idonate' ),
    'ZAMORA-CHINCHIPE' => __( 'Zamora-Chinchipe', 'idonate' ),
];
