<?php

global $states;

$states['PY'] = [
    'ALTOPARAGUAY'    => __( 'Alto Paraguay', 'idonate' ),
    'ALTOPARANA'      => __( 'Alto Parana', 'idonate' ),
    'AMAMBAY'         => __( 'Amambay', 'idonate' ),
    'ASUNCION'        => __( 'Asuncion', 'idonate' ),
    'BOQUERON'        => __( 'Boqueron', 'idonate' ),
    'CAAGUAZU'        => __( 'Caaguazu', 'idonate' ),
    'CAAZAPA'         => __( 'Caazapa', 'idonate' ),
    'CANINDEYU'       => __( 'Canindeyu', 'idonate' ),
    'CENTRAL'         => __( 'Central', 'idonate' ),
    'CONCEPCION'      => __( 'Concepcion', 'idonate' ),
    'CORDILLERA'      => __( 'Cordillera', 'idonate' ),
    'GUAIRA'          => __( 'Guaira', 'idonate' ),
    'ITAPUA'          => __( 'Itapua', 'idonate' ),
    'MISIONES'        => __( 'Misiones', 'idonate' ),
    'NEEMBUCU'        => __( 'Neembucu', 'idonate' ),
    'PARAGUARI'       => __( 'Paraguari', 'idonate' ),
    'PRESIDENTEHAYES' => __( 'Presidente Hayes', 'idonate' ),
    'SANPEDRO'        => __( 'San Pedro', 'idonate' ),
];
