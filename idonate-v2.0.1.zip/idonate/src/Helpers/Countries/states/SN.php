<?php

global $states;

$states['SN'] = [
    'DAKAR'       => __( 'Dakar', 'idonate' ),
    'DIOURBEL'    => __( 'Diourbel', 'idonate' ),
    'FATICK'      => __( 'Fatick', 'idonate' ),
    'KAOLACK'     => __( 'Kaolack', 'idonate' ),
    'KOLDA'       => __( 'Kolda', 'idonate' ),
    'LOUGA'       => __( 'Louga', 'idonate' ),
    'MATAM'       => __( 'Matam', 'idonate' ),
    'SAINT-LOUIS' => __( 'Saint-Louis', 'idonate' ),
    'TAMBACOUNDA' => __( 'Tambacounda', 'idonate' ),
    'THIES'       => __( 'Thies', 'idonate' ),
    'ZIGUINCHOR'  => __( 'Ziguinchor', 'idonate' ),
];
