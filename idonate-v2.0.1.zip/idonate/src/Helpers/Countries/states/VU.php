<?php

global $states;

$states['VU'] = [
    'MALAMPA' => __( 'Malampa', 'idonate' ),
    'PENAMA'  => __( 'Penama', 'idonate' ),
    'SANMA'   => __( 'Sanma', 'idonate' ),
    'SHEFA'   => __( 'Shefa', 'idonate' ),
    'TAFEA'   => __( 'Tafea', 'idonate' ),
    'TORBA'   => __( 'Torba', 'idonate' ),
];
