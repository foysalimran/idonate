<?php

global $states;

$states['BN'] = [
    'BELAIT'         => __( 'Belait', 'idonate' ),
    'BRUNEIANDMUARA' => __( 'Brunei and Muara', 'idonate' ),
    'TEMBURONG'      => __( 'Temburong', 'idonate' ),
    'TUTONG'         => __( 'Tutong', 'idonate' ),
];
