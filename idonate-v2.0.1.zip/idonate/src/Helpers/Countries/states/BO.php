<?php

global $states;

$states['BO'] = [
    'CHUQUISACA' => __( 'Chuquisaca', 'idonate' ),
    'COCHABAMBA' => __( 'Cochabamba', 'idonate' ),
    'BENI'       => __( 'Beni', 'idonate' ),
    'LAPAZ'      => __( 'La Paz', 'idonate' ),
    'ORURO'      => __( 'Oruro', 'idonate' ),
    'PANDO'      => __( 'Pando', 'idonate' ),
    'POTOSI'     => __( 'Potosi', 'idonate' ),
    'SANTACRUZ'  => __( 'Santa Cruz', 'idonate' ),
    'TARIJA'     => __( 'Tarija', 'idonate' ),
];
