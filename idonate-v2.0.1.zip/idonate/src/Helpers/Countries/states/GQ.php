<?php

global $states;

$states['GQ'] = [
    'ANNOBON'    => __( 'Annobon', 'idonate' ),
    'BIOKONORTE' => __( 'Bioko Norte', 'idonate' ),
    'BIOKOSUR'   => __( 'Bioko Sur', 'idonate' ),
    'CENTROSUR'  => __( 'Centro Sur', 'idonate' ),
    'KIE-NTEM'   => __( 'Kie-Ntem', 'idonate' ),
    'LITORAL'    => __( 'Litoral', 'idonate' ),
    'WELE-NZAS'  => __( 'Wele-Nzas', 'idonate' ),
];
