<?php

global $states;

$states['AL'] = [
    'BERAT'       => __( 'Berat', 'idonate' ),
    'DIBRES'      => __( 'Dibres', 'idonate' ),
    'DURRES'      => __( 'Durres', 'idonate' ),
    'ELBASAN'     => __( 'Elbasan', 'idonate' ),
    'FIER'        => __( 'Fier', 'idonate' ),
    'GJIROKASTRE' => __( 'Gjirokastre', 'idonate' ),
    'KORCE'       => __( 'Korce', 'idonate' ),
    'KUKES'       => __( 'Kukes', 'idonate' ),
    'LEZHE'       => __( 'Lezhe', 'idonate' ),
    'SHKODER'     => __( 'Shkoder', 'idonate' ),
    'TIRANE'      => __( 'Tirane', 'idonate' ),
    'VLORE'       => __( 'Vlore', 'idonate' ),
];
