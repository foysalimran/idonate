<?php

global $states;

$states['HR'] = [
    'BJELOVARSKO-BILOGORSKA' => __( 'Bjelovarsko-Bilogorska', 'idonate' ),
    'BRODSKO-POSAVSKA'       => __( 'Brodsko-Posavska', 'idonate' ),
    'DUBROVACKO-NERETVANSKA' => __( 'Dubrovacko-Neretvanska', 'idonate' ),
    'ISTARSKA'               => __( 'Istarska', 'idonate' ),
    'KARLOVACKA'             => __( 'Karlovacka', 'idonate' ),
    'KOPRIVNICKO-KRIZEVACKA' => __( 'Koprivnicko-Krizevacka', 'idonate' ),
    'KRAPINSKO-ZAGORSKA'     => __( 'Krapinsko-Zagorska', 'idonate' ),
    'LICKO-SENJSKA'          => __( 'Licko-Senjska', 'idonate' ),
    'MEDIMURSKA'             => __( 'Medimurska', 'idonate' ),
    'OSJECKO-BARANJSKA'      => __( 'Osjecko-Baranjska', 'idonate' ),
    'POZESKO-SLAVONSKA'      => __( 'Pozesko-Slavonska', 'idonate' ),
    'PRIMORSKO-GORANSKA'     => __( 'Primorsko-Goranska', 'idonate' ),
    'SIBENSKO-KNINSKA'       => __( 'Sibensko-Kninska', 'idonate' ),
    'SISACKO-MOSLAVACKA'     => __( 'Sisacko-Moslavacka', 'idonate' ),
    'SPLITSKO-DALMATINSKA'   => __( 'Splitsko-Dalmatinska', 'idonate' ),
    'VARAZDINSKA'            => __( 'Varazdinska', 'idonate' ),
    'VIROVITICKO-PODRAVSKA'  => __( 'Viroviticko-Podravska', 'idonate' ),
    'VUKOVARSKO-SRIJEMSKA'   => __( 'Vukovarsko-Srijemska', 'idonate' ),
    'ZADARSKA'               => __( 'Zadarska', 'idonate' ),
    'ZAGREB'                 => __( 'Zagreb', 'idonate' ),
    'ZAGREBACKA'             => __( 'Zagrebacka', 'idonate' ),
];
