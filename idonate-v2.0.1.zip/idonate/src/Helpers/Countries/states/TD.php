<?php

global $states;

$states['TD'] = [
    'BATHA'                 => __( 'Batha', 'idonate' ),
    'BILTINE'               => __( 'Biltine', 'idonate' ),
    'BORKOU-ENNEDI-TIBESTI' => __( 'Borkou-Ennedi-Tibesti', 'idonate' ),
    'CHARI-BAGUIRMI'        => __( 'Chari-Baguirmi', 'idonate' ),
    'GUéRA'                 => __( 'Guéra', 'idonate' ),
    'KANEM'                 => __( 'Kanem', 'idonate' ),
    'LAC'                   => __( 'Lac', 'idonate' ),
    'LOGONEOCCIDENTAL'      => __( 'Logone Occidental', 'idonate' ),
    'LOGONEORIENTAL'        => __( 'Logone Oriental', 'idonate' ),
    'MAYO-KEBBI'            => __( 'Mayo-Kebbi', 'idonate' ),
    'MOYEN-CHARI'           => __( 'Moyen-Chari', 'idonate' ),
    'OUADDAï'               => __( 'Ouaddaï', 'idonate' ),
    'SALAMAT'               => __( 'Salamat', 'idonate' ),
    'TANDJILE'              => __( 'Tandjile', 'idonate' ),
];
