<?php

global $states;

$states['CU'] = [
    'CAMAGUEY'         => __( 'Camaguey', 'idonate' ),
    'CIEGODEAVILA'     => __( 'Ciego de Avila', 'idonate' ),
    'CIENFUEGOS'       => __( 'Cienfuegos', 'idonate' ),
    'CIUDADDELAHABANA' => __( 'Ciudad de La Habana', 'idonate' ),
    'GRANMA'           => __( 'Granma', 'idonate' ),
    'GUANTANAMO'       => __( 'Guantanamo', 'idonate' ),
    'HOLGUIN'          => __( 'Holguin', 'idonate' ),
    'ISLADELAJUVENTUD' => __( 'Isla de la Juventud', 'idonate' ),
    'LAHABANA'         => __( 'La Habana', 'idonate' ),
    'LASTUNAS'         => __( 'Las Tunas', 'idonate' ),
    'MATANZAS'         => __( 'Matanzas', 'idonate' ),
    'PINARDELRIO'      => __( 'Pinar del Rio', 'idonate' ),
    'SANCTISPIRITUS'   => __( 'Sancti Spiritus', 'idonate' ),
    'SANTIAGODECUBA'   => __( 'Santiago de Cuba', 'idonate' ),
    'VILLACLARA'       => __( 'Villa Clara', 'idonate' ),
];
