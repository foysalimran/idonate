<?php

global $states;

$states['GH'] = [
    'ASHANTI'      => __( 'Ashanti', 'idonate' ),
    'BRONG-AHAFO'  => __( 'Brong-Ahafo', 'idonate' ),
    'CENTRAL'      => __( 'Central', 'idonate' ),
    'EASTERN'      => __( 'Eastern', 'idonate' ),
    'GREATERACCRA' => __( 'Greater Accra', 'idonate' ),
    'NORTHERN'     => __( 'Northern', 'idonate' ),
    'UPPEREAST'    => __( 'Upper East', 'idonate' ),
    'UPPERWEST'    => __( 'Upper West', 'idonate' ),
    'VOLTA'        => __( 'Volta', 'idonate' ),
    'WESTERN'      => __( 'Western', 'idonate' ),
];
