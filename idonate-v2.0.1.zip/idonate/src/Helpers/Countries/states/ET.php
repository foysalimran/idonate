<?php

global $states;

$states['ET'] = [
    'ADDISABABA'                                     => __( 'Addis Ababa', 'idonate' ),
    'AFAR'                                           => __( 'Afar', 'idonate' ),
    'AMHARA'                                         => __( 'Amhara', 'idonate' ),
    'BINSHANGULGUMUZ'                                => __( 'Binshangul Gumuz', 'idonate' ),
    'DIREDAWA'                                       => __( 'Dire Dawa', 'idonate' ),
    'GAMBELAHIZBOCH'                                 => __( 'Gambela Hizboch', 'idonate' ),
    'HARARI'                                         => __( 'Harari', 'idonate' ),
    'OROMIA'                                         => __( 'Oromia', 'idonate' ),
    'SOMALI'                                         => __( 'Somali', 'idonate' ),
    'TIGRAY'                                         => __( 'Tigray', 'idonate' ),
    'SOUTHERNNATIONS,NATIONALITIES,ANDPEOPLESREGION' => __( 'Southern Nations, Nationalities, and Peoples Region', 'idonate' ),
];
