<?php

global $states;

$states['HT'] = [
    'ARTIBONITE' => __( 'Artibonite', 'idonate' ),
    'CENTRE'     => __( 'Centre', 'idonate' ),
    "GRAND'ANSE" => __( "Grand 'Anse", 'idonate' ),
    'NORD'       => __( 'Nord', 'idonate' ),
    'NORD-EST'   => __( 'Nord-Est', 'idonate' ),
    'NORD-OUEST' => __( 'Nord-Ouest', 'idonate' ),
    'OUEST'      => __( 'Ouest', 'idonate' ),
    'SUD'        => __( 'Sud', 'idonate' ),
    'SUD-EST'    => __( 'Sud-Est', 'idonate' ),
];
