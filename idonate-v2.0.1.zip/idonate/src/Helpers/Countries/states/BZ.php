<?php

global $states;

$states['BZ'] = [
    'BELIZE'     => __( 'Belize', 'idonate' ),
    'CAYO'       => __( 'Cayo', 'idonate' ),
    'COROZAL'    => __( 'Corozal', 'idonate' ),
    'ORANGEWALK' => __( 'Orange Walk', 'idonate' ),
    'STANNCREEK' => __( 'Stann Creek', 'idonate' ),
    'TOLEDO'     => __( 'Toledo', 'idonate' ),
];
