<?php

global $states;

$states['BB'] = [
    'CHRISTCHURCH' => __( 'Christ Church', 'idonate' ),
    'SAINTANDREW'  => __( 'Saint Andrew', 'idonate' ),
    'SAINTGEORGE'  => __( 'Saint George', 'idonate' ),
    'SAINTJAMES'   => __( 'Saint James', 'idonate' ),
    'SAINTJOHN'    => __( 'Saint John', 'idonate' ),
    'SAINTJOSEPH'  => __( 'Saint Joseph', 'idonate' ),
    'SAINTLUCY'    => __( 'Saint Lucy', 'idonate' ),
    'SAINTMICHAEL' => __( 'Saint Michael', 'idonate' ),
    'SAINTPETER'   => __( 'Saint Peter', 'idonate' ),
    'SAINTPHILIP'  => __( 'Saint Philip', 'idonate' ),
    'SAINTTHOMAS'  => __( 'Saint Thomas', 'idonate' ),
];
