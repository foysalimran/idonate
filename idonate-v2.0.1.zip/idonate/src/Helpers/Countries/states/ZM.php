<?php

global $states;

$states['ZM'] = [
    'CENTRAL'       => __( 'Central', 'idonate' ),
    'COPPERBELT'    => __( 'Copperbelt', 'idonate' ),
    'EASTERN'       => __( 'Eastern', 'idonate' ),
    'LUAPULA'       => __( 'Luapula', 'idonate' ),
    'LUSAKA'        => __( 'Lusaka', 'idonate' ),
    'NORTHERN'      => __( 'Northern', 'idonate' ),
    'NORTH-WESTERN' => __( 'North-Western', 'idonate' ),
    'SOUTHERN'      => __( 'Southern', 'idonate' ),
    'WESTERN'       => __( 'Western', 'idonate' ),
];
