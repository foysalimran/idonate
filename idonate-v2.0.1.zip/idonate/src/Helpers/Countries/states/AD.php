<?php

global $states;

$states['AD'] = [
    'ANDORRALAVELLA'     => __( 'Andorra la Vella', 'idonate' ),
    'CANILLO'            => __( 'Canillo', 'idonate' ),
    'ENCAMP'             => __( 'Encamp', 'idonate' ),
    'ESCALDES-ENGORDANY' => __( 'Escaldes-Engordany', 'idonate' ),
    'LAMASSANA'          => __( 'La Massana', 'idonate' ),
    'ORDINO'             => __( 'Ordino', 'idonate' ),
    'SANTJULIADELORIA'   => __( 'Sant Julia de Loria', 'idonate' ),
];
