<?php

global $states;

$states['CF'] = [
    'BAMINGUI-BANGORAN' => __( 'Bamingui-Bangoran', 'idonate' ),
    'BANGUI'            => __( 'Bangui', 'idonate' ),
    'BASSE-KOTTO'       => __( 'Basse-Kotto', 'idonate' ),
    'HAUTE-KOTTO'       => __( 'Haute-Kotto', 'idonate' ),
    'HAUT-MBOMOU'       => __( 'Haut-Mbomou', 'idonate' ),
    'KEMO'              => __( 'Kemo', 'idonate' ),
    'LOBAYE'            => __( 'Lobaye', 'idonate' ),
    'MAMBERE-KADEI'     => __( 'Mambere-Kadei', 'idonate' ),
    'MBOMOU'            => __( 'Mbomou', 'idonate' ),
    'NANA-GREBIZI'      => __( 'Nana-Grebizi', 'idonate' ),
    'NANA-MAMBERE'      => __( 'Nana-Mambere', 'idonate' ),
    'OMBELLA-MPOKO'     => __( 'Ombella-Mpoko', 'idonate' ),
    'OUAKA'             => __( 'Ouaka', 'idonate' ),
    'OUHAM'             => __( 'Ouham', 'idonate' ),
    'OUHAM-PENDE'       => __( 'Ouham-Pende', 'idonate' ),
    'SANGHA-MBAERE'     => __( 'Sangha-Mbaere', 'idonate' ),
    'VAKAGA'            => __( 'Vakaga', 'idonate' ),
];
