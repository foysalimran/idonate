<?php

global $states;

$states['RW'] = [
    'BUTARE'       => __( 'Butare', 'idonate' ),
    'BYUMBA'       => __( 'Byumba', 'idonate' ),
    'CYANGUGU'     => __( 'Cyangugu', 'idonate' ),
    'GIKONGORO'    => __( 'Gikongoro', 'idonate' ),
    'GISENYI'      => __( 'Gisenyi', 'idonate' ),
    'GITARAMA'     => __( 'Gitarama', 'idonate' ),
    'KIBUNGO'      => __( 'Kibungo', 'idonate' ),
    'KIBUYE'       => __( 'Kibuye', 'idonate' ),
    'KIGALIRURALE' => __( 'Kigali Rurale', 'idonate' ),
    'KIGALI-VILLE' => __( 'Kigali-ville', 'idonate' ),
    'UMUTARA'      => __( 'Umutara', 'idonate' ),
    'RUHENGERI'    => __( 'Ruhengeri', 'idonate' ),
];
