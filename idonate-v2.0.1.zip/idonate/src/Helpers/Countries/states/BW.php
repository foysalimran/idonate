<?php

global $states;

$states['BW'] = [
    'CENTRAL'   => __( 'Central', 'idonate' ),
    'GHANZI'    => __( 'Ghanzi', 'idonate' ),
    'KGALAGADI' => __( 'Kgalagadi', 'idonate' ),
    'KGATLENG'  => __( 'Kgatleng', 'idonate' ),
    'KWENENG'   => __( 'Kweneng', 'idonate' ),
    'NORTHEAST' => __( 'North East', 'idonate' ),
    'NORTHWEST' => __( 'North West', 'idonate' ),
    'SOUTHEAST' => __( 'South East', 'idonate' ),
    'SOUTHERN'  => __( 'Southern', 'idonate' ),
];
