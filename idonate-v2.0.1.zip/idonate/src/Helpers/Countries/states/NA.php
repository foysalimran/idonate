<?php

global $states;

$states['NA'] = [
    'CAPRIVI'      => __( 'Caprivi', 'idonate' ),
    'ERONGO'       => __( 'Erongo', 'idonate' ),
    'HARDAP'       => __( 'Hardap', 'idonate' ),
    'KARAS'        => __( 'Karas', 'idonate' ),
    'KHOMAS'       => __( 'Khomas', 'idonate' ),
    'KUNENE'       => __( 'Kunene', 'idonate' ),
    'OHANGWENA'    => __( 'Ohangwena', 'idonate' ),
    'OKAVANGO'     => __( 'Okavango', 'idonate' ),
    'OMAHEKE'      => __( 'Omaheke', 'idonate' ),
    'OMUSATI'      => __( 'Omusati', 'idonate' ),
    'OSHANA'       => __( 'Oshana', 'idonate' ),
    'OSHIKOTO'     => __( 'Oshikoto', 'idonate' ),
    'OTJOZONDJUPA' => __( 'Otjozondjupa', 'idonate' ),
];
