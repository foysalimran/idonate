<?php

global $states;

$states['ZW'] = [
    'BULAWAYO'           => __( 'Bulawayo', 'idonate' ),
    'HARARE'             => __( 'Harare', 'idonate' ),
    'MANICALAND'         => __( 'Manicaland', 'idonate' ),
    'MASHONALANDCENTRAL' => __( 'Mashonaland Central', 'idonate' ),
    'MASHONALANDEAST'    => __( 'Mashonaland East', 'idonate' ),
    'MASHONALANDWEST'    => __( 'Mashonaland West', 'idonate' ),
    'MASVINGO'           => __( 'Masvingo', 'idonate' ),
    'MATABELELANDNORTH'  => __( 'Matabeleland North', 'idonate' ),
    'MATABELELANDSOUTH'  => __( 'Matabeleland South', 'idonate' ),
    'MIDLANDS'           => __( 'Midlands', 'idonate' ),
];
