<?php

global $states;

$states['JM'] = [
    'CLARENDON'      => __( 'Clarendon', 'idonate' ),
    'HANOVER'        => __( 'Hanover', 'idonate' ),
    'KINGSTON'       => __( 'Kingston', 'idonate' ),
    'MANCHESTER'     => __( 'Manchester', 'idonate' ),
    'PORTLAND'       => __( 'Portland', 'idonate' ),
    'SAINTANDREW'    => __( 'Saint Andrew', 'idonate' ),
    'SAINTANN'       => __( 'Saint Ann', 'idonate' ),
    'SAINTCATHERINE' => __( 'Saint Catherine', 'idonate' ),
    'SAINTELIZABETH' => __( 'Saint Elizabeth', 'idonate' ),
    'SAINTJAMES'     => __( 'Saint James', 'idonate' ),
    'SAINTMARY'      => __( 'Saint Mary', 'idonate' ),
    'SAINTTHOMAS'    => __( 'Saint Thomas', 'idonate' ),
    'TRELAWNY'       => __( 'Trelawny', 'idonate' ),
    'WESTMORELAND'   => __( 'Westmoreland', 'idonate' ),
];
