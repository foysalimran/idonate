<?php

global $states;

$states['LA'] = [
    'ATTAPU'         => __( 'Attapu', 'idonate' ),
    'BOKEO'          => __( 'Bokeo', 'idonate' ),
    'BOLIKHAMXAI'    => __( 'Bolikhamxai', 'idonate' ),
    'CHAMPASAK'      => __( 'Champasak', 'idonate' ),
    'HOUAPHAN'       => __( 'Houaphan', 'idonate' ),
    'KHAMMOUAN'      => __( 'Khammouan', 'idonate' ),
    'LOUANGNAMTHA'   => __( 'Louangnamtha', 'idonate' ),
    'LOUANGPHRABANG' => __( 'Louangphrabang', 'idonate' ),
    'OUDOMXAI'       => __( 'Oudomxai', 'idonate' ),
    'PHONGSALI'      => __( 'Phongsali', 'idonate' ),
    'SALAVAN'        => __( 'Salavan', 'idonate' ),
    'SAVANNAKHET'    => __( 'Savannakhet', 'idonate' ),
    'VIANGCHAN'      => __( 'Viangchan', 'idonate' ),
    'VIANGCHAN'      => __( 'Viangchan', 'idonate' ),
    'XAIGNABOULI'    => __( 'Xaignabouli', 'idonate' ),
    'XAISOMBOUN'     => __( 'Xaisomboun', 'idonate' ),
    'XEKONG'         => __( 'Xekong', 'idonate' ),
    'XIANGKHOANG'    => __( 'Xiangkhoang', 'idonate' ),
];
