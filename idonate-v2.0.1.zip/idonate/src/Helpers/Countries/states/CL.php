<?php

global $states;

$states['CL'] = [
'AYSEN'                         => __( 'Aysen', 'idonate' ),
'ANTOFAGASTA'                   => __( 'Antofagasta', 'idonate' ),
'ARAUCANIA'                     => __( 'Araucania', 'idonate' ),
'ATACAMA'                       => __( 'Atacama', 'idonate' ),
'BIO-BIO'                       => __( 'Bio-Bio', 'idonate' ),
'COQUIMBO'                      => __( 'Coquimbo', 'idonate' ),
"O'HIGGINS"                     => __( "O'Higgins", 'idonate' ),
'LOSLAGOS'                      => __( 'Los Lagos', 'idonate' ),
'MAGALLANESYLAANTARTICACHILENA' => __( 'Magallanes y la Antartica Chilena', 'idonate' ),
'MAULE'                         => __( 'Maule', 'idonate' ),
'SANTIAGOREGIONMETROPOLITANA'   => __( 'Santiago Region Metropolitana', 'idonate' ),
'TARAPACA'                      => __( 'Tarapaca', 'idonate' ),
'VALPARAISO'                    => __( 'Valparaiso', 'idonate' ),
];
