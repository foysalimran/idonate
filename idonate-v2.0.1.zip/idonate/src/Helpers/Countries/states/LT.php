<?php

global $states;

$states['LT'] = [
    'ALYTAUS'      => __( 'Alytaus', 'idonate' ),
    'KAUNO'        => __( 'Kauno', 'idonate' ),
    'KLAIPEDOS'    => __( 'Klaipedos', 'idonate' ),
    'MARIJAMPOLES' => __( 'Marijampoles', 'idonate' ),
    'PANEVEZIO'    => __( 'Panevezio', 'idonate' ),
    'SIAULIU'      => __( 'Siauliu', 'idonate' ),
    'TAURAGES'     => __( 'Taurages', 'idonate' ),
    'TELSIU'       => __( 'Telsiu', 'idonate' ),
    'UTENOS'       => __( 'Utenos', 'idonate' ),
    'VILNIAUS'     => __( 'Vilniaus', 'idonate' ),
];
