<?php

global $states;

$states['MW'] = [
    'BALAKA'     => __( 'Balaka', 'idonate' ),
    'BLANTYRE'   => __( 'Blantyre', 'idonate' ),
    'CHIKWAWA'   => __( 'Chikwawa', 'idonate' ),
    'CHIRADZULU' => __( 'Chiradzulu', 'idonate' ),
    'CHITIPA'    => __( 'Chitipa', 'idonate' ),
    'DEDZA'      => __( 'Dedza', 'idonate' ),
    'DOWA'       => __( 'Dowa', 'idonate' ),
    'KARONGA'    => __( 'Karonga', 'idonate' ),
    'KASUNGU'    => __( 'Kasungu', 'idonate' ),
    'LIKOMA'     => __( 'Likoma', 'idonate' ),
    'LILONGWE'   => __( 'Lilongwe', 'idonate' ),
    'MACHINGA'   => __( 'Machinga', 'idonate' ),
    'MANGOCHI'   => __( 'Mangochi', 'idonate' ),
    'MCHINJI'    => __( 'Mchinji', 'idonate' ),
    'MULANJE'    => __( 'Mulanje', 'idonate' ),
    'MWANZA'     => __( 'Mwanza', 'idonate' ),
    'MZIMBA'     => __( 'Mzimba', 'idonate' ),
    'NTCHEU'     => __( 'Ntcheu', 'idonate' ),
    'NKHATABAY'  => __( 'Nkhata Bay', 'idonate' ),
    'NKHOTAKOTA' => __( 'Nkhotakota', 'idonate' ),
    'NSANJE'     => __( 'Nsanje', 'idonate' ),
    'NTCHISI'    => __( 'Ntchisi', 'idonate' ),
    'PHALOMBE'   => __( 'Phalombe', 'idonate' ),
    'RUMPHI'     => __( 'Rumphi', 'idonate' ),
    'SALIMA'     => __( 'Salima', 'idonate' ),
    'THYOLO'     => __( 'Thyolo', 'idonate' ),
    'ZOMBA'      => __( 'Zomba', 'idonate' ),
];
