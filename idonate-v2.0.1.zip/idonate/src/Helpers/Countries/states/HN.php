<?php

global $states;

$states['HN'] = [
    'ATLANTIDA'        => __( 'Atlantida', 'idonate' ),
    'CHOLUTECA'        => __( 'Choluteca', 'idonate' ),
    'COLON'            => __( 'Colon', 'idonate' ),
    'COMAYAGUA'        => __( 'Comayagua', 'idonate' ),
    'COPAN'            => __( 'Copan', 'idonate' ),
    'CORTES'           => __( 'Cortes', 'idonate' ),
    'ELPARAISO'        => __( 'El Paraiso', 'idonate' ),
    'FRANCISCOMORAZAN' => __( 'Francisco Morazan', 'idonate' ),
    'GRACIASADIOS'     => __( 'Gracias a Dios', 'idonate' ),
    'INTIBUCA'         => __( 'Intibuca', 'idonate' ),
    'ISLASDELABAHIA'   => __( 'Islas de la Bahia', 'idonate' ),
    'LAPAZ'            => __( 'La Paz', 'idonate' ),
    'LEMPIRA'          => __( 'Lempira', 'idonate' ),
    'OCOTEPEQUE'       => __( 'Ocotepeque', 'idonate' ),
    'OLANCHO'          => __( 'Olancho', 'idonate' ),
    'SANTABARBARA'     => __( 'Santa Barbara', 'idonate' ),
    'VALLE'            => __( 'Valle', 'idonate' ),
    'YORO'             => __( 'Yoro', 'idonate' ),
];
