<?php

global $states;

$states['LS'] = [
'BEREA'        => __( 'Berea', 'idonate' ),
'BUTHA-BUTHE'  => __( 'Butha-Buthe', 'idonate' ),
'LERIBE'       => __( 'Leribe', 'idonate' ),
'MAFETENG'     => __( 'Mafeteng', 'idonate' ),
'MASERU'       => __( 'Maseru', 'idonate' ),
"MOHALE'SHOEK" => __( "Mohale's Hoek", 'idonate' ),
'MOKHOTLONG'   => __( 'Mokhotlong', 'idonate' ),
"QACHA'SNEK"   => __( "Qacha's Nek", 'idonate' ),
'QUTHING'      => __( 'Quthing', 'idonate' ),
'THABA-TSEKA'  => __( 'Thaba-Tseka', 'idonate' ),
];
