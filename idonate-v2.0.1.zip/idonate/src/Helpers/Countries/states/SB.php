<?php

global $states;

$states['SB'] = [
    'CENTRAL'           => __( 'Central', 'idonate' ),
    'CHOISEUL'          => __( 'Choiseul', 'idonate' ),
    'GUADALCANAL'       => __( 'Guadalcanal', 'idonate' ),
    'HONIARA'           => __( 'Honiara', 'idonate' ),
    'ISABEL'            => __( 'Isabel', 'idonate' ),
    'MAKIRA'            => __( 'Makira', 'idonate' ),
    'MALAITA'           => __( 'Malaita', 'idonate' ),
    'RENNELLANDBELLONA' => __( 'Rennell and Bellona', 'idonate' ),
    'TEMOTU'            => __( 'Temotu', 'idonate' ),
    'WESTERN'           => __( 'Western', 'idonate' ),
];
