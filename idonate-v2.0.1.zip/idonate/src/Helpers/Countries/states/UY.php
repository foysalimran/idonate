<?php

global $states;

$states['UY'] = [
    'ARTIGAS'      => __( 'Artigas', 'idonate' ),
    'CANELONES'    => __( 'Canelones', 'idonate' ),
    'CERROLARGO'   => __( 'Cerro Largo', 'idonate' ),
    'COLONIA'      => __( 'Colonia', 'idonate' ),
    'DURAZNO'      => __( 'Durazno', 'idonate' ),
    'FLORES'       => __( 'Flores', 'idonate' ),
    'FLORIDA'      => __( 'Florida', 'idonate' ),
    'LAVALLEJA'    => __( 'Lavalleja', 'idonate' ),
    'MALDONADO'    => __( 'Maldonado', 'idonate' ),
    'MONTEVIDEO'   => __( 'Montevideo', 'idonate' ),
    'PAYSANDU'     => __( 'Paysandu', 'idonate' ),
    'RIONEGRO'     => __( 'Rio Negro', 'idonate' ),
    'RIVERA'       => __( 'Rivera', 'idonate' ),
    'ROCHA'        => __( 'Rocha', 'idonate' ),
    'SALTO'        => __( 'Salto', 'idonate' ),
    'SANJOSE'      => __( 'San Jose', 'idonate' ),
    'SORIANO'      => __( 'Soriano', 'idonate' ),
    'TACUAREMBO'   => __( 'Tacuarembo', 'idonate' ),
    'TREINTAYTRES' => __( 'Treinta y Tres', 'idonate' ),
];
