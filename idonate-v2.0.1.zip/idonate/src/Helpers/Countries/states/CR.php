<?php

global $states;

$states['CR'] = [
    'ALAJUELA'   => __( 'Alajuela', 'idonate' ),
    'CARTAGO'    => __( 'Cartago', 'idonate' ),
    'GUANACASTE' => __( 'Guanacaste', 'idonate' ),
    'HEREDIA'    => __( 'Heredia', 'idonate' ),
    'LIMON'      => __( 'Limon', 'idonate' ),
    'PUNTARENAS' => __( 'Puntarenas', 'idonate' ),
    'SANJOSE'    => __( 'San Jose', 'idonate' ),
];
