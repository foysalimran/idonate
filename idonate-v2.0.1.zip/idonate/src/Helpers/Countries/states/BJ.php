<?php

global $states;

$states['BJ'] = [
    'ALIBORI'    => __( 'Alibori', 'idonate' ),
    'ATAKORA'    => __( 'Atakora', 'idonate' ),
    'ATLANTIQUE' => __( 'Atlantique', 'idonate' ),
    'BORGOU'     => __( 'Borgou', 'idonate' ),
    'COLLINES'   => __( 'Collines', 'idonate' ),
    'DONGA'      => __( 'Donga', 'idonate' ),
    'KOUFFO'     => __( 'Kouffo', 'idonate' ),
    'LITTORAL'   => __( 'Littoral', 'idonate' ),
    'MONO'       => __( 'Mono', 'idonate' ),
    'OUEME'      => __( 'Oueme', 'idonate' ),
    'PLATEAU'    => __( 'Plateau', 'idonate' ),
    'ZOU'        => __( 'Zou', 'idonate' ),
];
