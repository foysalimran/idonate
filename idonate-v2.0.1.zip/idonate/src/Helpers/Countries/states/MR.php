<?php

global $states;

$states['MR'] = [
    'ADRAR'             => __( 'Adrar', 'idonate' ),
    'ASSABA'            => __( 'Assaba', 'idonate' ),
    'BRAKNA'            => __( 'Brakna', 'idonate' ),
    'DAKHLETNOUADHIBOU' => __( 'Dakhlet Nouadhibou', 'idonate' ),
    'GORGOL'            => __( 'Gorgol', 'idonate' ),
    'GUIDIMAKA'         => __( 'Guidimaka', 'idonate' ),
    'HODHECHCHARGUI'    => __( 'Hodh Ech Chargui', 'idonate' ),
    'HODHELGHARBI'      => __( 'Hodh El Gharbi', 'idonate' ),
    'INCHIRI'           => __( 'Inchiri', 'idonate' ),
    'NOUAKCHOTT'        => __( 'Nouakchott', 'idonate' ),
    'TAGANT'            => __( 'Tagant', 'idonate' ),
    'TIRISZEMMOUR'      => __( 'Tiris Zemmour', 'idonate' ),
    'TRARZA'            => __( 'Trarza', 'idonate' ),
];
