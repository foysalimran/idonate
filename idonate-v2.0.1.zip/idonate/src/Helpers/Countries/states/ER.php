<?php

global $states;

$states['ER'] = [
    'ANSEBA'              => __( 'Anseba', 'idonate' ),
    'DEBUB'               => __( 'Debub', 'idonate' ),
    "DEBUBAWIK'EYIHBAHRI" => __( "Debubawi K'eyih Bahri", 'idonate' ),
    'GASHBARKA'           => __( 'Gash Barka', 'idonate' ),
    "MA'AKEL"             => __( "Ma'akel", 'idonate' ),
    'SEMENAWIKEYIHBAHRI'  => __( 'Semenawi Keyih Bahri', 'idonate' ),
];
