<?php

global $states;

$states['DJ'] = [
    'ALISABIH' => __( 'Ali Sabih', 'idonate' ),
    'DIKHIL'   => __( 'Dikhil', 'idonate' ),
    'DJIBOUTI' => __( 'Djibouti', 'idonate' ),
    'OBOCK'    => __( 'Obock', 'idonate' ),
    'TADJOURA' => __( 'Tadjoura', 'idonate' ),
];
