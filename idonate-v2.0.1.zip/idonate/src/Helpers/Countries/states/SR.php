<?php

global $states;

$states['SR'] = [
    'BROKOPONDO' => __( 'Brokopondo', 'idonate' ),
    'COMMEWIJNE' => __( 'Commewijne', 'idonate' ),
    'CORONIE'    => __( 'Coronie', 'idonate' ),
    'MAROWIJNE'  => __( 'Marowijne', 'idonate' ),
    'NICKERIE'   => __( 'Nickerie', 'idonate' ),
    'PARA'       => __( 'Para', 'idonate' ),
    'PARAMARIBO' => __( 'Paramaribo', 'idonate' ),
    'SARAMACCA'  => __( 'Saramacca', 'idonate' ),
    'SIPALIWINI' => __( 'Sipaliwini', 'idonate' ),
    'WANICA'     => __( 'Wanica', 'idonate' ),
];
