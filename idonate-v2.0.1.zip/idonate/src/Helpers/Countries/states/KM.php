<?php

global $states;

$states['KM'] = [
    'GRANDECOMORE(NJAZIDJA)' => __( 'Grande Comore (Njazidja)', 'idonate' ),
    'ANJOUAN(NZWANI)'        => __( 'Anjouan (Nzwani)', 'idonate' ),
    'MOHELI(MWALI)'          => __( 'Moheli (Mwali)', 'idonate' ),
];
