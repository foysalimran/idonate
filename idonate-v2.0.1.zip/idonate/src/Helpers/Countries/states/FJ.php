<?php

global $states;

$states['FJ'] = [
    'CENTRAL(SUVA)'    => __( 'Central (Suva)', 'idonate' ),
    'EASTERN(LEVUKA)'  => __( 'Eastern (Levuka)', 'idonate' ),
    'NORTHERN(LABASA)' => __( 'Northern (Labasa)', 'idonate' ),
    'ROTUMA'           => __( 'Rotuma', 'idonate' ),
    'WESTERN(LAUTOKA)' => __( 'Western (Lautoka)', 'idonate' ),
];
