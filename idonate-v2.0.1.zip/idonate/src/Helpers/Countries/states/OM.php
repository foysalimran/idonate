<?php

global $states;

$states['OM'] = [
    'ADDAKHILIYAH' => __( 'Ad Dakhiliyah', 'idonate' ),
    'ALBATINAH'    => __( 'Al Batinah', 'idonate' ),
    'ALWUSTA'      => __( 'Al Wusta', 'idonate' ),
    'ASHSHARQIYAH' => __( 'Ash Sharqiyah', 'idonate' ),
    'AZZAHIRAH'    => __( 'Az Zahirah', 'idonate' ),
    'MASQAT'       => __( 'Masqat', 'idonate' ),
    'MUSANDAM'     => __( 'Musandam', 'idonate' ),
    'DHOFAR'       => __( 'Dhofar', 'idonate' ),
];
