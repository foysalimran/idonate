<?php

global $states;

$states['TM'] = [
    'AHALWELAYATY(ASHGABAT)'     => __( 'Ahal Welayaty (Ashgabat)', 'idonate' ),
    'BALKANWELAYATY(BALKANABAT)' => __( 'Balkan Welayaty (Balkanabat)', 'idonate' ),
    'DASHOGUZWELAYATY'           => __( 'Dashoguz Welayaty', 'idonate' ),
    'LEBAPWELAYATY(TURKMENABAT)' => __( 'Lebap Welayaty (Turkmenabat)', 'idonate' ),
    'MARYWELAYATY'               => __( 'Mary Welayaty', 'idonate' ),
];
