<?php

global $states;

$states['UZ'] = [
    'ANDIJONVILOYATI'              => __( 'Andijon Viloyati', 'idonate' ),
    'BUXOROVILOYATI'               => __( 'Buxoro Viloyati', 'idonate' ),
    "FARG'ONAVILOYATI"             => __( "Farg'ona Viloyati", 'idonate' ),
    'JIZZAXVILOYATI'               => __( 'Jizzax Viloyati', 'idonate' ),
    'NAMANGANVILOYATI'             => __( 'Namangan Viloyati', 'idonate' ),
    'NAVOIYVILOYATI'               => __( 'Navoiy Viloyati', 'idonate' ),
    'QASHQADARYOVILOYATI'          => __( 'Qashqadaryo Viloyati', 'idonate' ),
    "QARAQALPOG'ISTONRESPUBLIKASI" => __( "Qaraqalpog'iston Respublikasi", 'idonate' ),
    'SAMARQANDVILOYATI'            => __( 'Samarqand Viloyati', 'idonate' ),
    'SIRDARYOVILOYATI'             => __( 'Sirdaryo Viloyati', 'idonate' ),
    'SURXONDARYOVILOYATI'          => __( 'Surxondaryo Viloyati', 'idonate' ),
    'TOSHKENTSHAHRI'               => __( 'Toshkent Shahri', 'idonate' ),
    'TOSHKENTVILOYATI'             => __( 'Toshkent Viloyati', 'idonate' ),
    'XORAZMVILOYATI'               => __( 'Xorazm Viloyati', 'idonate' ),
];
