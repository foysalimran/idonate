<?php

global $states;

$states['GL'] = [
    'AVANNAA(NORDGRONLAND)' => __( 'Avannaa (Nordgronland)', 'idonate' ),
    'TUNU(OSTGRONLAND)'     => __( 'Tunu (Ostgronland)', 'idonate' ),
    'KITAA(VESTGRONLAND)'   => __( 'Kitaa (Vestgronland)', 'idonate' ),
];
