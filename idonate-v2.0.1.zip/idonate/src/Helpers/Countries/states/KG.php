<?php

global $states;

$states['KG'] = [
    'BATKENOBLASTY'     => __( 'Batken Oblasty', 'idonate' ),
    'BISHKEKSHAARY'     => __( 'Bishkek Shaary', 'idonate' ),
    'CHUYOBLASTY'       => __( 'Chuy Oblasty', 'idonate' ),
    'JALAL-ABADOBLASTY' => __( 'Jalal-Abad Oblasty', 'idonate' ),
    'NARYNOBLASTY'      => __( 'Naryn Oblasty', 'idonate' ),
    'OSHOBLASTY'        => __( 'Osh Oblasty', 'idonate' ),
    'TALASOBLASTY'      => __( 'Talas Oblasty', 'idonate' ),
    'YSYK-KOLOBLASTY'   => __( 'Ysyk-Kol Oblasty', 'idonate' ),
];
