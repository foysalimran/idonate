<?php

global $states;

$states['GD'] = [
    'CARRIACOUANDPETITMARTINIQUE' => __( 'Carriacou and Petit Martinique', 'idonate' ),
    'SAINTANDREW'                 => __( 'Saint Andrew', 'idonate' ),
    'SAINTDAVID'                  => __( 'Saint David', 'idonate' ),
    'SAINTGEORGE'                 => __( 'Saint George', 'idonate' ),
    'SAINTJOHN'                   => __( 'Saint John', 'idonate' ),
    'SAINTMARK'                   => __( 'Saint Mark', 'idonate' ),
    'SAINTPATRICK'                => __( 'Saint Patrick', 'idonate' ),
];
