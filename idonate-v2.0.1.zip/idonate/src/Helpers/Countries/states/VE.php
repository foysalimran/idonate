<?php

global $states;

$states['VE'] = [
    'AMAZONAS'              => __( 'Amazonas', 'idonate' ),
    'ANZOATEGUI'            => __( 'Anzoategui', 'idonate' ),
    'APURE'                 => __( 'Apure', 'idonate' ),
    'ARAGUA'                => __( 'Aragua', 'idonate' ),
    'BARINAS'               => __( 'Barinas', 'idonate' ),
    'BOLIVAR'               => __( 'Bolivar', 'idonate' ),
    'CARABOBO'              => __( 'Carabobo', 'idonate' ),
    'COJEDES'               => __( 'Cojedes', 'idonate' ),
    'DELTAAMACURO'          => __( 'Delta Amacuro', 'idonate' ),
    'DEPENDENCIASFEDERALES' => __( 'Dependencias Federales', 'idonate' ),
    'DISTRITOFEDERAL'       => __( 'Distrito Federal', 'idonate' ),
    'FALCON'                => __( 'Falcon', 'idonate' ),
    'GUARICO'               => __( 'Guarico', 'idonate' ),
    'LARA'                  => __( 'Lara', 'idonate' ),
    'MERIDA'                => __( 'Merida', 'idonate' ),
    'MIRANDA'               => __( 'Miranda', 'idonate' ),
    'MONAGAS'               => __( 'Monagas', 'idonate' ),
    'NUEVAESPARTA'          => __( 'Nueva Esparta', 'idonate' ),
    'PORTUGUESA'            => __( 'Portuguesa', 'idonate' ),
    'SUCRE'                 => __( 'Sucre', 'idonate' ),
    'TACHIRA'               => __( 'Tachira', 'idonate' ),
    'TRUJILLO'              => __( 'Trujillo', 'idonate' ),
    'VARGAS'                => __( 'Vargas', 'idonate' ),
    'YARACUY'               => __( 'Yaracuy', 'idonate' ),
    'ZULIA'                 => __( 'Zulia', 'idonate' ),
];
