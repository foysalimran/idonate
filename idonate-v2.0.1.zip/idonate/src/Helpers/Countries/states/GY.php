<?php

global $states;

$states['GY'] = [
    'BARIMA-WAINI'                  => __( 'Barima-Waini', 'idonate' ),
    'CUYUNI-MAZARUNI'               => __( 'Cuyuni-Mazaruni', 'idonate' ),
    'DEMERARA-MAHAICA'              => __( 'Demerara-Mahaica', 'idonate' ),
    'EASTBERBICE-CORENTYNE'         => __( 'East Berbice-Corentyne', 'idonate' ),
    'ESSEQUIBOISLANDS-WESTDEMERARA' => __( 'Essequibo Islands-West Demerara', 'idonate' ),
    'MAHAICA-BERBICE'               => __( 'Mahaica-Berbice', 'idonate' ),
    'POMEROON-SUPENAAM'             => __( 'Pomeroon-Supenaam', 'idonate' ),
    'POTARO-SIPARUNI'               => __( 'Potaro-Siparuni', 'idonate' ),
    'UPPERDEMERARA-BERBICE'         => __( 'Upper Demerara-Berbice', 'idonate' ),
    'UPPERTAKUTU-UPPERESSEQUIBO'    => __( 'Upper Takutu-Upper Essequibo', 'idonate' ),
];
