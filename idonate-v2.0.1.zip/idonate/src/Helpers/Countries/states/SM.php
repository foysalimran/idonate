<?php

global $states;

$states['SM'] = [
    'ACQUAVIVA'      => __( 'Acquaviva', 'idonate' ),
    'BORGOMAGGIORE'  => __( 'Borgo Maggiore', 'idonate' ),
    'CHIESANUOVA'    => __( 'Chiesanuova', 'idonate' ),
    'DOMAGNANO'      => __( 'Domagnano', 'idonate' ),
    'FAETANO'        => __( 'Faetano', 'idonate' ),
    'FIORENTINO'     => __( 'Fiorentino', 'idonate' ),
    'MONTEGIARDINO'  => __( 'Montegiardino', 'idonate' ),
    'SANMARINOCITTA' => __( 'San Marino Citta', 'idonate' ),
    'SERRAVALLE'     => __( 'Serravalle', 'idonate' ),
];
