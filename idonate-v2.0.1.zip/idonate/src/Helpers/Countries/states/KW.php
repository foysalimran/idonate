<?php

global $states;

$states['KW'] = [
    'ALAHMADI'         => __( 'Al Ahmadi', 'idonate' ),
    'ALFARWANIYAH'     => __( 'Al Farwaniyah', 'idonate' ),
    'ALASIMAH'         => __( 'Al Asimah', 'idonate' ),
    'ALJAHRA'          => __( 'Al Jahra', 'idonate' ),
    'HAWALLI'          => __( 'Hawalli', 'idonate' ),
    'MUBARAKAL-KABEER' => __( 'Mubarak Al-Kabeer', 'idonate' ),
];
