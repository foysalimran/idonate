<?php

global $states;

$states['NI'] = [
    'ATLANTICONORTE' => __( 'Atlantico Norte', 'idonate' ),
    'ATLANTICOSUR'   => __( 'Atlantico Sur', 'idonate' ),
    'BOACO'          => __( 'Boaco', 'idonate' ),
    'CARAZO'         => __( 'Carazo', 'idonate' ),
    'CHINANDEGA'     => __( 'Chinandega', 'idonate' ),
    'CHONTALES'      => __( 'Chontales', 'idonate' ),
    'ESTELI'         => __( 'Esteli', 'idonate' ),
    'GRANADA'        => __( 'Granada', 'idonate' ),
    'JINOTEGA'       => __( 'Jinotega', 'idonate' ),
    'LEON'           => __( 'Leon', 'idonate' ),
    'MADRIZ'         => __( 'Madriz', 'idonate' ),
    'MANAGUA'        => __( 'Managua', 'idonate' ),
    'MASAYA'         => __( 'Masaya', 'idonate' ),
    'MATAGALPA'      => __( 'Matagalpa', 'idonate' ),
    'NUEVASEGOVIA'   => __( 'Nueva Segovia', 'idonate' ),
    'RIOSANJUAN'     => __( 'Rio San Juan', 'idonate' ),
    'RIVAS'          => __( 'Rivas', 'idonate' ),
];
