<?php

global $states;

$states['MN'] = [
    'ARHANGAY'    => __( 'Arhangay', 'idonate' ),
    'BAYANHONGOR' => __( 'Bayanhongor', 'idonate' ),
    'BAYAN-OLGIY' => __( 'Bayan-Olgiy', 'idonate' ),
    'BULGAN'      => __( 'Bulgan', 'idonate' ),
    'DARHANUUL'   => __( 'Darhan Uul', 'idonate' ),
    'DORNOD'      => __( 'Dornod', 'idonate' ),
    'DORNOGOVI'   => __( 'Dornogovi', 'idonate' ),
    'DUNDGOVI'    => __( 'Dundgovi', 'idonate' ),
    'DZAVHAN'     => __( 'Dzavhan', 'idonate' ),
    'GOVI-ALTAY'  => __( 'Govi-Altay', 'idonate' ),
    'GOVI-SUMBER' => __( 'Govi-Sumber', 'idonate' ),
    'HENTIY'      => __( 'Hentiy', 'idonate' ),
    'HOVD'        => __( 'Hovd', 'idonate' ),
    'HOVSGOL'     => __( 'Hovsgol', 'idonate' ),
    'OMNOGOVI'    => __( 'Omnogovi', 'idonate' ),
    'ORHON'       => __( 'Orhon', 'idonate' ),
    'OVORHANGAY'  => __( 'Ovorhangay', 'idonate' ),
    'SELENGE'     => __( 'Selenge', 'idonate' ),
    'SUHBAATAR'   => __( 'Suhbaatar', 'idonate' ),
    'TOV'         => __( 'Tov', 'idonate' ),
    'ULAANBAATAR' => __( 'Ulaanbaatar', 'idonate' ),
    'UVS'         => __( 'Uvs', 'idonate' ),
];
