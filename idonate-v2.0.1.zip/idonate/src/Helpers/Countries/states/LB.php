<?php

global $states;

$states['LB'] = [
    'BEYROUTH'   => __( 'Beyrouth', 'idonate' ),
    'BEQAA'      => __( 'Beqaa', 'idonate' ),
    'LIBAN-NORD' => __( 'Liban-Nord', 'idonate' ),
    'LIBAN-SUD'  => __( 'Liban-Sud', 'idonate' ),
    'MONT-LIBAN' => __( 'Mont-Liban', 'idonate' ),
    'NABATIYE'   => __( 'Nabatiye', 'idonate' ),
];
