<?php

global $states;

$states['AE'] = [
    'ABUDHABI'      => __( 'Abu Dhabi', 'idonate' ),
    "'AJMAN"        => __( "'Ajman", 'idonate' ),
    'ALFUJAYRAH'    => __( 'Al Fujayrah', 'idonate' ),
    'SHARJAH'       => __( 'Sharjah', 'idonate' ),
    'DUBAI'         => __( 'Dubai', 'idonate' ),
    "RA'SALKHAYMAH" => __( "Ra's al Khaymah", 'idonate' ),
    'UMMALQAYWAYN'  => __( 'Umm al Qaywayn', 'idonate' ),
];
