<?php

global $states;

$states['BM'] = [
    'DEVONSHIRE'    => __( 'Devonshire', 'idonate' ),
    'HAMILTON'      => __( 'Hamilton', 'idonate' ),
    'HAMILTON'      => __( 'Hamilton', 'idonate' ),
    'PAGET'         => __( 'Paget', 'idonate' ),
    'PEMBROKE'      => __( 'Pembroke', 'idonate' ),
    'SAINTGEORGE'   => __( 'Saint George', 'idonate' ),
    "SAINTGEORGE'S" => __( "Saint George's", 'idonate' ),
    'SANDYS'        => __( 'Sandys', 'idonate' ),
    "SMITH'S"       => __( "Smith's", 'idonate' ),
    'SOUTHAMPTON'   => __( 'Southampton', 'idonate' ),
    'WARWICK'       => __( 'Warwick', 'idonate' ),
];
