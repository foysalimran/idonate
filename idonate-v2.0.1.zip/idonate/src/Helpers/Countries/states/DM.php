<?php

global $states;

$states['DM'] = [
    'SAINTANDREW'  => __( 'Saint Andrew', 'idonate' ),
    'SAINTDAVID'   => __( 'Saint David', 'idonate' ),
    'SAINTGEORGE'  => __( 'Saint George', 'idonate' ),
    'SAINTJOHN'    => __( 'Saint John', 'idonate' ),
    'SAINTJOSEPH'  => __( 'Saint Joseph', 'idonate' ),
    'SAINTLUKE'    => __( 'Saint Luke', 'idonate' ),
    'SAINTMARK'    => __( 'Saint Mark', 'idonate' ),
    'SAINTPATRICK' => __( 'Saint Patrick', 'idonate' ),
    'SAINTPAUL'    => __( 'Saint Paul', 'idonate' ),
    'SAINTPETER'   => __( 'Saint Peter', 'idonate' ),
];
