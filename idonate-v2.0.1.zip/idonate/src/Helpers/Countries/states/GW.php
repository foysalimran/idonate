<?php

global $states;

$states['GW'] = [
    'BAFATA'  => __( 'Bafata', 'idonate' ),
    'BIOMBO'  => __( 'Biombo', 'idonate' ),
    'BISSAU'  => __( 'Bissau', 'idonate' ),
    'BOLAMA'  => __( 'Bolama', 'idonate' ),
    'CACHEU'  => __( 'Cacheu', 'idonate' ),
    'GABU'    => __( 'Gabu', 'idonate' ),
    'OIO'     => __( 'Oio', 'idonate' ),
    'QUINARA' => __( 'Quinara', 'idonate' ),
    'TOMBALI' => __( 'Tombali', 'idonate' ),
];
