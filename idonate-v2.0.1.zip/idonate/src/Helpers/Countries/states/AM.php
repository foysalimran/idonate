<?php

global $states;

$states['AM'] = [
    'ARAGATSOTN'    => __( 'Aragatsotn', 'idonate' ),
    'ARARAT'        => __( 'Ararat', 'idonate' ),
    'ARMAVIR'       => __( 'Armavir', 'idonate' ),
    "GEGHARK'UNIK'" => __( "Geghark'unik'", 'idonate' ),
    "KOTAYK'"       => __( "Kotayk'", 'idonate' ),
    'LORRI'         => __( 'Lorri', 'idonate' ),
    'SHIRAK'        => __( 'Shirak', 'idonate' ),
    "SYUNIK'"       => __( "Syunik'", 'idonate' ),
    'TAVUSH'        => __( 'Tavush', 'idonate' ),
    "VAYOTS'DZOR"   => __( "Vayots' Dzor", 'idonate' ),
    'YEREVAN'       => __( 'Yerevan', 'idonate' ),
];
