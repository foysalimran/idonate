<?php

global $states;

$states['NE'] = [
    'AGADEZ'    => __( 'Agadez', 'idonate' ),
    'DIFFA'     => __( 'Diffa', 'idonate' ),
    'DOSSO'     => __( 'Dosso', 'idonate' ),
    'MARADI'    => __( 'Maradi', 'idonate' ),
    'NIAMEY'    => __( 'Niamey', 'idonate' ),
    'TAHOUA'    => __( 'Tahoua', 'idonate' ),
    'TILLABERI' => __( 'Tillaberi', 'idonate' ),
    'ZINDER'    => __( 'Zinder', 'idonate' ),
];
