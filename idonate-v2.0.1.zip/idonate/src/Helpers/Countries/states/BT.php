<?php

global $states;

$states['BT'] = [
    'BUMTHANG'        => __( 'Bumthang', 'idonate' ),
    'CHUKHA'          => __( 'Chukha', 'idonate' ),
    'DAGANA'          => __( 'Dagana', 'idonate' ),
    'GASA'            => __( 'Gasa', 'idonate' ),
    'HAA'             => __( 'Haa', 'idonate' ),
    'LHUNTSE'         => __( 'Lhuntse', 'idonate' ),
    'MONGAR'          => __( 'Mongar', 'idonate' ),
    'PARO'            => __( 'Paro', 'idonate' ),
    'PEMAGATSHEL'     => __( 'Pemagatshel', 'idonate' ),
    'PUNAKHA'         => __( 'Punakha', 'idonate' ),
    'SAMDRUPJONGKHAR' => __( 'Samdrup Jongkhar', 'idonate' ),
    'SAMTSE'          => __( 'Samtse', 'idonate' ),
    'SARPANG'         => __( 'Sarpang', 'idonate' ),
    'THIMPHU'         => __( 'Thimphu', 'idonate' ),
    'TRASHIGANG'      => __( 'Trashigang', 'idonate' ),
    'TRASHIYANGSTE'   => __( 'Trashiyangste', 'idonate' ),
    'TRONGSA'         => __( 'Trongsa', 'idonate' ),
    'TSIRANG'         => __( 'Tsirang', 'idonate' ),
    'WANGDUEPHODRANG' => __( 'Wangdue Phodrang', 'idonate' ),
    'ZHEMGANG'        => __( 'Zhemgang', 'idonate' ),
];
