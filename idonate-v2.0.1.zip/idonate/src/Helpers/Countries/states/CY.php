<?php

global $states;

$states['CY'] = [
    'FAMAGUSTA' => __( 'Famagusta', 'idonate' ),
    'KYRENIA'   => __( 'Kyrenia', 'idonate' ),
    'LARNACA'   => __( 'Larnaca', 'idonate' ),
    'LIMASSOL'  => __( 'Limassol', 'idonate' ),
    'NICOSIA'   => __( 'Nicosia', 'idonate' ),
    'PAPHOS'    => __( 'Paphos', 'idonate' ),
];
