<?php

global $states;

$states['SZ'] = [
    'HHOHHO'     => __( 'Hhohho', 'idonate' ),
    'LUBOMBO'    => __( 'Lubombo', 'idonate' ),
    'MANZINI'    => __( 'Manzini', 'idonate' ),
    'SHISELWENI' => __( 'Shiselweni', 'idonate' ),
];
