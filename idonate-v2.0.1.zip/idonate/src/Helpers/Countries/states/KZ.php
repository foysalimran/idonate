<?php

global $states;

$states['KZ'] = [
    'ALMATYOBLYSY'             => __( 'Almaty Oblysy', 'idonate' ),
    'ALMATYQALASY'             => __( 'Almaty Qalasy', 'idonate' ),
    'AQMOLAOBLYSY'             => __( 'Aqmola Oblysy', 'idonate' ),
    'AQTOBEOBLYSY'             => __( 'Aqtobe Oblysy', 'idonate' ),
    'ASTANAQALASY'             => __( 'Astana Qalasy', 'idonate' ),
    'ATYRAUOBLYSY'             => __( 'Atyrau Oblysy', 'idonate' ),
    'BATYSQAZAQSTANOBLYSY'     => __( 'Batys Qazaqstan Oblysy', 'idonate' ),
    'BAYQONGYRQALASY'          => __( 'Bayqongyr Qalasy', 'idonate' ),
    'MANGGHYSTAUOBLYSY'        => __( 'Mangghystau Oblysy', 'idonate' ),
    'ONGTUSTIKQAZAQSTANOBLYSY' => __( 'Ongtustik Qazaqstan Oblysy', 'idonate' ),
    'PAVLODAROBLYSY'           => __( 'Pavlodar Oblysy', 'idonate' ),
    'QARAGHANDYOBLYSY'         => __( 'Qaraghandy Oblysy', 'idonate' ),
    'QOSTANAYOBLYSY'           => __( 'Qostanay Oblysy', 'idonate' ),
    'QYZYLORDAOBLYSY'          => __( 'Qyzylorda Oblysy', 'idonate' ),
    'SHYGHYSQAZAQSTANOBLYSY'   => __( 'Shyghys Qazaqstan Oblysy', 'idonate' ),
    'SOLTUSTIKQAZAQSTANOBLYSY' => __( 'Soltustik Qazaqstan Oblysy', 'idonate' ),
    'ZHAMBYLOBLYSY'            => __( 'Zhambyl Oblysy', 'idonate' ),
];
