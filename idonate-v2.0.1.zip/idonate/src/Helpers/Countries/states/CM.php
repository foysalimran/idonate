<?php

global $states;

$states['CM'] = [
    'ADAMAOUA'     => __( 'Adamaoua', 'idonate' ),
    'CENTRE'       => __( 'Centre', 'idonate' ),
    'EST'          => __( 'Est', 'idonate' ),
    'EXTREME-NORD' => __( 'Extreme-Nord', 'idonate' ),
    'LITTORAL'     => __( 'Littoral', 'idonate' ),
    'NORD'         => __( 'Nord', 'idonate' ),
    'NORD-OUEST'   => __( 'Nord-Ouest', 'idonate' ),
    'OUEST'        => __( 'Ouest', 'idonate' ),
    'SUD'          => __( 'Sud', 'idonate' ),
    'SUD-OUEST'    => __( 'Sud-Ouest', 'idonate' ),
];
