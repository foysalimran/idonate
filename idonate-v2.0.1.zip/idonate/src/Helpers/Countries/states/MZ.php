<?php

global $states;

$states['MZ'] = [
    'CABODELGADO'    => __( 'Cabo Delgado', 'idonate' ),
    'GAZA'           => __( 'Gaza', 'idonate' ),
    'INHAMBANE'      => __( 'Inhambane', 'idonate' ),
    'MANICA'         => __( 'Manica', 'idonate' ),
    'MAPUTO'         => __( 'Maputo', 'idonate' ),
    'CIDADEDEMAPUTO' => __( 'Cidade de Maputo', 'idonate' ),
    'NAMPULA'        => __( 'Nampula', 'idonate' ),
    'NIASSA'         => __( 'Niassa', 'idonate' ),
    'SOFALA'         => __( 'Sofala', 'idonate' ),
    'TETE'           => __( 'Tete', 'idonate' ),
    'ZAMBEZIA'       => __( 'Zambezia', 'idonate' ),
];
