<?php

global $states;

$states['BY'] = [
    'BREST'      => __( 'Brest', 'idonate' ),
    'HOMYEL'     => __( 'Homyel', 'idonate' ),
    'HORADMINSK' => __( 'Horad Minsk', 'idonate' ),
    'HRODNA'     => __( 'Hrodna', 'idonate' ),
    'MAHILYOW'   => __( 'Mahilyow', 'idonate' ),
    'MINSK'      => __( 'Minsk', 'idonate' ),
    'VITSYEBSK'  => __( 'Vitsyebsk', 'idonate' ),
];
