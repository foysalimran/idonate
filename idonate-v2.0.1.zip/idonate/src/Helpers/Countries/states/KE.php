<?php

global $states;

$states['KE'] = [
    'CENTRAL'      => __( 'Central', 'idonate' ),
    'COAST'        => __( 'Coast', 'idonate' ),
    'EASTERN'      => __( 'Eastern', 'idonate' ),
    'NAIROBIAREA'  => __( 'Nairobi Area', 'idonate' ),
    'NORTHEASTERN' => __( 'North Eastern', 'idonate' ),
    'NYANZA'       => __( 'Nyanza', 'idonate' ),
    'RIFTVALLEY'   => __( 'Rift Valley', 'idonate' ),
    'WESTERN'      => __( 'Western', 'idonate' ),
];
