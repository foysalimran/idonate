<?php

global $states;

$states['ML'] = [
    'BAMAKO(CAPITAL)' => __( 'Bamako (Capital)', 'idonate' ),
    'GAO'             => __( 'Gao', 'idonate' ),
    'KAYES'           => __( 'Kayes', 'idonate' ),
    'KIDAL'           => __( 'Kidal', 'idonate' ),
    'KOULIKORO'       => __( 'Koulikoro', 'idonate' ),
    'MOPTI'           => __( 'Mopti', 'idonate' ),
    'SEGOU'           => __( 'Segou', 'idonate' ),
    'SIKASSO'         => __( 'Sikasso', 'idonate' ),
    'TOMBOUCTOU'      => __( 'Tombouctou', 'idonate' ),
];
