<?php

global $states;

$states['PA'] = [
    'BOCASDELTORO' => __( 'Bocas del Toro', 'idonate' ),
    'CHIRIQUI'     => __( 'Chiriqui', 'idonate' ),
    'COCLE'        => __( 'Cocle', 'idonate' ),
    'COLON'        => __( 'Colon', 'idonate' ),
    'DARIEN'       => __( 'Darien', 'idonate' ),
    'HERRERA'      => __( 'Herrera', 'idonate' ),
    'LOSSANTOS'    => __( 'Los Santos', 'idonate' ),
    'PANAMA'       => __( 'Panama', 'idonate' ),
    'SANBLAS'      => __( 'San Blas', 'idonate' ),
    'VERAGUAS'     => __( 'Veraguas', 'idonate' ),
];
