<?php

global $states;

$states['MU'] = [
    'AGALEGAISLANDS'        => __( 'Agalega Islands', 'idonate' ),
    'BLACKRIVER'            => __( 'Black River', 'idonate' ),
    'CARGADOSCARAJOSSHOALS' => __( 'Cargados Carajos Shoals', 'idonate' ),
    'FLACQ'                 => __( 'Flacq', 'idonate' ),
    'GRANDPORT'             => __( 'Grand Port', 'idonate' ),
    'MOKA'                  => __( 'Moka', 'idonate' ),
    'PAMPLEMOUSSES'         => __( 'Pamplemousses', 'idonate' ),
    'PLAINESWILHEMS'        => __( 'Plaines Wilhems', 'idonate' ),
    'PORTLOUIS'             => __( 'Port Louis', 'idonate' ),
    'RIVIEREDUREMPART'      => __( 'Riviere du Rempart', 'idonate' ),
    'RODRIGUES'             => __( 'Rodrigues', 'idonate' ),
    'SAVANNE'               => __( 'Savanne', 'idonate' ),
];
