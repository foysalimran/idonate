<?php

global $states;

$states['SV'] = [
    'AHUACHAPAN'   => __( 'Ahuachapan', 'idonate' ),
    'CABANAS'      => __( 'Cabanas', 'idonate' ),
    'CHALATENANGO' => __( 'Chalatenango', 'idonate' ),
    'CUSCATLAN'    => __( 'Cuscatlan', 'idonate' ),
    'LALIBERTAD'   => __( 'La Libertad', 'idonate' ),
    'LAPAZ'        => __( 'La Paz', 'idonate' ),
    'LAUNION'      => __( 'La Union', 'idonate' ),
    'MORAZAN'      => __( 'Morazan', 'idonate' ),
    'SANMIGUEL'    => __( 'San Miguel', 'idonate' ),
    'SANSALVADOR'  => __( 'San Salvador', 'idonate' ),
    'SANTAANA'     => __( 'Santa Ana', 'idonate' ),
    'SANVICENTE'   => __( 'San Vicente', 'idonate' ),
    'SONSONATE'    => __( 'Sonsonate', 'idonate' ),
    'USULUTAN'     => __( 'Usulutan', 'idonate' ),
];
