<?php

global $states;

$states['QA'] = [
    'ADDAWHAH'         => __( 'Ad Dawhah', 'idonate' ),
    'ALGHUWAYRIYAH'    => __( 'Al Ghuwayriyah', 'idonate' ),
    'ALJUMAYLIYAH'     => __( 'Al Jumayliyah', 'idonate' ),
    'ALKHAWR'          => __( 'Al Khawr', 'idonate' ),
    'ALWAKRAH'         => __( 'Al Wakrah', 'idonate' ),
    'ARRAYYAN'         => __( 'Ar Rayyan', 'idonate' ),
    'JARAYANALBATINAH' => __( 'Jarayan al Batinah', 'idonate' ),
    'MADINATASHSHAMAL' => __( 'Madinat ash Shamal', 'idonate' ),
    "UMMSA'ID"         => __( "Umm Sa'id", 'idonate' ),
    'UMMSALAL'         => __( 'Umm Salal', 'idonate' ),
];
