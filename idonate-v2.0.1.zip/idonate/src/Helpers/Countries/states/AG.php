<?php

global $states;

$states['AG'] = [
    'BARBUDA'     => __( 'Barbuda', 'idonate' ),
    'REDONDA'     => __( 'Redonda', 'idonate' ),
    'SAINTGEORGE' => __( 'Saint George', 'idonate' ),
    'SAINTJOHN'   => __( 'Saint John', 'idonate' ),
    'SAINTMARY'   => __( 'Saint Mary', 'idonate' ),
    'SAINTPAUL'   => __( 'Saint Paul', 'idonate' ),
    'SAINTPETER'  => __( 'Saint Peter', 'idonate' ),
    'SAINTPHILIP' => __( 'Saint Philip', 'idonate' ),
];
