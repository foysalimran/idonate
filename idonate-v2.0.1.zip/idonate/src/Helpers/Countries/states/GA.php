<?php

global $states;

$states['GA'] = [
    'ESTUAIRE'        => __( 'Estuaire', 'idonate' ),
    'HAUT-OGOOUE'     => __( 'Haut-Ogooue', 'idonate' ),
    'MOYEN-OGOOUE'    => __( 'Moyen-Ogooue', 'idonate' ),
    'NGOUNIE'         => __( 'Ngounie', 'idonate' ),
    'NYANGA'          => __( 'Nyanga', 'idonate' ),
    'OGOOUE-IVINDO'   => __( 'Ogooue-Ivindo', 'idonate' ),
    'OGOOUE-LOLO'     => __( 'Ogooue-Lolo', 'idonate' ),
    'OGOOUE-MARITIME' => __( 'Ogooue-Maritime', 'idonate' ),
    'WOLEU-NTEM'      => __( 'Woleu-Ntem', 'idonate' ),
];
