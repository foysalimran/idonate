<?php

global $states;

$states['MG'] = [
    'ANTANANARIVO' => __( 'Antananarivo', 'idonate' ),
    'ANTSIRANANA'  => __( 'Antsiranana', 'idonate' ),
    'FIANARANTSOA' => __( 'Fianarantsoa', 'idonate' ),
    'MAHAJANGA'    => __( 'Mahajanga', 'idonate' ),
    'TOAMASINA'    => __( 'Toamasina', 'idonate' ),
    'TOLIARA'      => __( 'Toliara', 'idonate' ),
];
