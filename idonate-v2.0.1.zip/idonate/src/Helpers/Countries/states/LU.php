<?php

global $states;

$states['LU'] = [
    'DIEKIRCH'     => __( 'Diekirch', 'idonate' ),
    'GREVENMACHER' => __( 'Grevenmacher', 'idonate' ),
    'LUXEMBOURG'   => __( 'Luxembourg', 'idonate' ),
];
