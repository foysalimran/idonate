<?php

global $states;

$states['YE'] = [
    'ABYAN'      => __( 'Abyan', 'idonate' ),
    "'ADAN"      => __( "'Adan", 'idonate' ),
    "ADDALI'"    => __( "Ad Dali'", 'idonate' ),
    "ALBAYDA'"   => __( "Al Bayda'", 'idonate' ),
    'ALHUDAYDAH' => __( 'Al Hudaydah', 'idonate' ),
    'ALJAWF'     => __( 'Al Jawf', 'idonate' ),
    'ALMAHRAH'   => __( 'Al Mahrah', 'idonate' ),
    'ALMAHWIT'   => __( 'Al Mahwit', 'idonate' ),
    "'AMRAN"     => __( "'Amran", 'idonate' ),
    'DHAMAR'     => __( 'Dhamar', 'idonate' ),
    'HADRAMAWT'  => __( 'Hadramawt', 'idonate' ),
    'HAJJAH'     => __( 'Hajjah', 'idonate' ),
    'IBB'        => __( 'Ibb', 'idonate' ),
    'LAHIJ'      => __( 'Lahij', 'idonate' ),
    "MA'RIB"     => __( "Ma'rib", 'idonate' ),
    "SA'DAH"     => __( "Sa'dah", 'idonate' ),
    "SAN'A'"     => __( "San'a'", 'idonate' ),
    'SHABWAH'    => __( 'Shabwah', 'idonate' ),
    "TA'IZZ"     => __( "Ta'izz", 'idonate' ),
];
