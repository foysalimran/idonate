<?php

global $states;

$states['TG'] = [
    'KARA'     => __( 'Kara', 'idonate' ),
    'PLATEAUX' => __( 'Plateaux', 'idonate' ),
    'SAVANES'  => __( 'Savanes', 'idonate' ),
    'CENTRALE' => __( 'Centrale', 'idonate' ),
    'MARITIME' => __( 'Maritime', 'idonate' ),
];
