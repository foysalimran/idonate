<?php

global $states;

$states['TT'] = [
    'COUVA'         => __( 'Couva', 'idonate' ),
    'DIEGOMARTIN'   => __( 'Diego Martin', 'idonate' ),
    'MAYARO'        => __( 'Mayaro', 'idonate' ),
    'PENAL'         => __( 'Penal', 'idonate' ),
    'PRINCESTOWN'   => __( 'Princes Town', 'idonate' ),
    'SANGREGRANDE'  => __( 'Sangre Grande', 'idonate' ),
    'SANJUAN'       => __( 'San Juan', 'idonate' ),
    'SIPARIA'       => __( 'Siparia', 'idonate' ),
    'TUNAPUNA'      => __( 'Tunapuna', 'idonate' ),
    'PORT-OF-SPAIN' => __( 'Port-of-Spain', 'idonate' ),
    'SANFERNANDO'   => __( 'San Fernando', 'idonate' ),
    'ARIMA'         => __( 'Arima', 'idonate' ),
    'POINTFORTIN'   => __( 'Point Fortin', 'idonate' ),
    'CHAGUANAS'     => __( 'Chaguanas', 'idonate' ),
    'TOBAGO'        => __( 'Tobago', 'idonate' ),
];
