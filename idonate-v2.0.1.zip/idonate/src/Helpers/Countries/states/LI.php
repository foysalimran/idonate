<?php

global $states;

$states['LI'] = [
    'BALZERS'      => __( 'Balzers', 'idonate' ),
    'ESCHEN'       => __( 'Eschen', 'idonate' ),
    'GAMPRIN'      => __( 'Gamprin', 'idonate' ),
    'MAUREN'       => __( 'Mauren', 'idonate' ),
    'PLANKEN'      => __( 'Planken', 'idonate' ),
    'RUGGELL'      => __( 'Ruggell', 'idonate' ),
    'SCHAAN'       => __( 'Schaan', 'idonate' ),
    'SCHELLENBERG' => __( 'Schellenberg', 'idonate' ),
    'TRIESEN'      => __( 'Triesen', 'idonate' ),
    'TRIESENBERG'  => __( 'Triesenberg', 'idonate' ),
    'VADUZ'        => __( 'Vaduz', 'idonate' ),
];
